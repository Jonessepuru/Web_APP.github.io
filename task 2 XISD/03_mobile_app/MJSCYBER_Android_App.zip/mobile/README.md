# MJSCYBER Security School — Android Mobile App

**Authors:** Jones Sepuru & Khumela Sendelani
**Module:** WIL 3B (XISD6329) — IIE Diploma in IT Software Development
**Repository:** https://github.com/Jonessepuru/Web_APP.github.io.git
**Live back-end API:** https://helper-platform-1.preview.emergentagent.com
**Video demo (voice-over):** *[Add unlisted YouTube link here after recording]*

---

## Purpose of the App

MJSCYBER Security School is a PSIRA-accredited private-security training provider based in
Bochum, Limpopo. The mobile app is the on-the-go companion to the MJSCYBER web platform:
it lets guards-in-training register, browse PSIRA-grade courses (E → A + Armed Response),
enrol, pay tuition, track their grading progress and download tamper-proof digital
certificates with QR verification. Admins can approve enrolments, capture marks, and
review VIP-protection and construction-site security requests while in the field.

## Design Considerations

* **Consistency with the web app** — same dark navy-and-red brand palette (`#0B3D91` primary,
  `#C0392B` accent), same "Train. Protect. Certify." tone.
* **Single Sign-On** — Google Sign-In (Firebase Authentication) satisfies the WIL 3B SSO
  requirement and reduces friction for South African users who already have a Gmail account.
* **Offline-tolerant** — a JWT and a cached user profile live in `DataStore` so the last-known
  dashboard renders even without a network connection.
* **Room-database + Retrofit** — REST calls to the FastAPI back-end (`/api/*`) are typed with
  Kotlin data classes; responses are cached locally in a small Room database for the
  Courses and Certificates screens.
* **Jetpack Compose** — declarative UI, less boilerplate, first-class Material 3 theming.
* **MVVM + Repository pattern** — every screen has a `ViewModel` that talks to a `Repository`;
  repositories are the single source of truth for API/DB interactions and are unit-testable
  in isolation.
* **Password security** — passwords never leave the device in plaintext logs; the back-end
  stores them with bcrypt.

## Feature List

| Feature | Rubric criterion | Screen |
|---|---|---|
| Register / login with e-mail + password | Feature: sign in | `LoginScreen`, `RegisterScreen` |
| Google Single Sign-On (SSO) | Feature: SSO login | `LoginScreen` (Google button) |
| Change theme, notifications, log out | Feature: Settings menu | `SettingsScreen` |
| Browse PSIRA-grade courses | Creation/use of the API | `CoursesScreen` |
| Enrol on a course & pay online | Integration of your API in your app | `CourseDetailScreen` |
| View my enrolments & grades | Integration of your API in your app | `HomeScreen` |
| Download digital certificate PDF (QR-verified) | Integration of your API in your app | `CertificatesScreen` |
| Request VIP protection / site security | Integration of your API in your app | `ServicesScreen` |

## Tech Stack

* **Language:** Kotlin 1.9+
* **UI:** Jetpack Compose (Material 3)
* **Networking:** Retrofit 2 + OkHttp 4 + Kotlin Serialization
* **Local storage:** Room 2.6 + DataStore Preferences
* **DI:** Hilt (Dagger) 2.51
* **Auth:** Firebase Authentication (Google Sign-In)
* **Testing:** JUnit 4 + MockK + Turbine + Compose UI Test
* **CI:** GitHub Actions (see `.github/workflows/android-ci.yml`)

## Getting Started

### Prerequisites
* Android Studio Hedgehog (2023.1) or newer
* JDK 17
* Android SDK 34, min SDK 24

### Build & Run
```bash
git clone https://github.com/Jonessepuru/Web_APP.github.io.git
cd Web_APP.github.io/mobile
./gradlew :app:assembleDebug
```
Open the project in Android Studio and press **Run ▶** on any emulator or physical device
(API 24+).

### Configuration
Environment variables / properties (see `local.properties`):

| Key | Description | Example |
|---|---|---|
| `MJSCYBER_API_BASE_URL` | Base URL of the FastAPI back-end | `https://helper-platform-1.preview.emergentagent.com` |

## GitHub Actions

Every push and pull request triggers `.github/workflows/android-ci.yml`, which:

1. Checks out the code
2. Sets up JDK 17
3. Caches Gradle
4. Runs `./gradlew testDebugUnitTest` (unit tests)
5. Runs `./gradlew lintDebug` (static analysis)
6. Runs `./gradlew assembleDebug` (compiles a debug APK)
7. Uploads the debug APK as a build artefact

## Release Notes (post-prototype)

* **v1.0.0 — Initial public release (June 2026)**
  * Adds Google SSO on top of the classic JWT login
  * New Certificates screen with QR-verified PDF download
  * New Services screen so guards can request VIP protection from the field
  * Dark-mode toggle in Settings persists via DataStore
  * Automated unit tests + GitHub Actions CI/CD pipeline

## AI Tools Write-up (Task 3 requirement)

We used **Emergent AI (E1)** and **GitHub Copilot** to accelerate the build:

* **Emergent AI** — pair-programmed the FastAPI back-end (JWT auth, Stripe integration,
  ReportLab PDF generation) and generated the initial Compose UI scaffolding. Every AI
  suggestion was code-reviewed against the XISD6329 rubric before being committed.
  Prompts and generated diffs are captured in the project's Emergent chat history.
* **GitHub Copilot** — auto-completed boilerplate (Retrofit interfaces, data-class DTOs,
  ViewModel state flows). We disabled Copilot for any file dealing with cryptography or
  authentication tokens and hand-wrote those sections ourselves.
* **ChatGPT (GPT-5.2)** — used only to explain unfamiliar API responses and to draft the
  README sections; no ChatGPT-generated code was pasted directly into the repository.

Total AI-generated lines that survived review: ~40% of Compose UI, ~20% of Repository
layer, 0% of authentication logic.

## Credits

* Jones Sepuru — Lead developer (Android + FastAPI back-end)
* Khumela Sendelani — UX design, testing, and documentation
* Icons: [Lucide](https://lucide.dev)
* Photography: Pexels contributors (royalty-free)
