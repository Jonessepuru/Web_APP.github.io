# Add project specific ProGuard rules here.
-keepattributes Signature
-keepattributes *Annotation*
-keep,allowobfuscation,allowshrinking class kotlin.Metadata

# Retrofit + kotlinx.serialization
-keep,includedescriptorclasses class co.za.mjscyber.**$$serializer { *; }
-keepclassmembers class co.za.mjscyber.** { *** Companion; }
-keepclasseswithmembers class co.za.mjscyber.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# OkHttp
-dontwarn okhttp3.internal.**
-dontwarn okio.**
