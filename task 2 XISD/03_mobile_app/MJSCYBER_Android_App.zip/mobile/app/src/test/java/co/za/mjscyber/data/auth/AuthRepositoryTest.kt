package co.za.mjscyber.data.auth

import co.za.mjscyber.data.api.ApiClient
import co.za.mjscyber.data.api.MjscyberApi
import co.za.mjscyber.data.dto.LoginRequest
import co.za.mjscyber.data.dto.SsoLoginRequest
import co.za.mjscyber.data.dto.TokenResponse
import co.za.mjscyber.data.dto.User
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Unit test — verifies AuthRepository correctly delegates to the API and persists the
 * session token/profile on success, and surfaces failures via Result.failure.
 *
 * This test hits the requirement in the XISD6329 rubric: "Automated testing on the
 * main functionality of the app".
 */
class AuthRepositoryTest {

    private lateinit var api: MjscyberApi
    private lateinit var client: ApiClient
    private lateinit var session: SessionStore
    private lateinit var repo: AuthRepository

    private val fakeToken = TokenResponse(
        access_token = "jwt-abc",
        user = User(
            id = "u1", email = "guardian@mjscyber.co.za", role = "student",
            full_name = "Test Guardian", phone = null, id_number = null
        )
    )

    @Before
    fun setUp() {
        api     = mockk(relaxed = true)
        client  = mockk { io.mockk.every { api } returns this@AuthRepositoryTest.api }
        session = mockk(relaxed = true)
        repo    = AuthRepository(client, session)
    }

    @Test
    fun `login lowercases and trims email then saves session on success`() = runTest {
        coEvery { api.login(any()) } returns fakeToken

        val result = repo.login("  Guardian@MJSCYBER.co.za  ", "S3cure!")

        assertTrue(result.isSuccess)
        assertEquals(fakeToken, result.getOrNull())
        coVerify { api.login(LoginRequest("guardian@mjscyber.co.za", "S3cure!")) }
        coVerify { session.save("jwt-abc", "guardian@mjscyber.co.za", "Test Guardian", "student") }
    }

    @Test
    fun `login returns failure and does not save session on api error`() = runTest {
        coEvery { api.login(any()) } throws RuntimeException("401")

        val result = repo.login("guardian@mjscyber.co.za", "wrong")

        assertTrue(result.isFailure)
        coVerify(exactly = 0) { session.save(any(), any(), any(), any()) }
    }

    @Test
    fun `sso login forwards google id token and saves session`() = runTest {
        coEvery { api.ssoGoogle(any()) } returns fakeToken

        val result = repo.ssoGoogle("google-id-token-123")

        assertTrue(result.isSuccess)
        coVerify { api.ssoGoogle(SsoLoginRequest("google-id-token-123")) }
        coVerify { session.save("jwt-abc", any(), any(), any()) }
    }

    @Test
    fun `logout clears the session store`() = runTest {
        repo.logout()
        coVerify { session.clear() }
    }
}
