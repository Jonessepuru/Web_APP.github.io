package co.za.mjscyber.ui.login

import java.net.UnknownHostException
import org.junit.Assert.assertEquals
import org.junit.Test

class LoginErrorMappingTest {

    @Test
    fun `UnknownHostException maps to network message`() {
        val msg = UnknownHostException("no-dns").userMessage()
        assertEquals("No internet connection. Please check your network and try again.", msg)
    }

    @Test
    fun `Generic exception falls back to trimmed message`() {
        val msg = RuntimeException("something went sideways").userMessage()
        assertEquals("something went sideways", msg)
    }

    @Test
    fun `Null message returns fallback`() {
        val msg = object : RuntimeException(null as String?) {}.userMessage()
        assertEquals("Unexpected error.", msg)
    }
}
