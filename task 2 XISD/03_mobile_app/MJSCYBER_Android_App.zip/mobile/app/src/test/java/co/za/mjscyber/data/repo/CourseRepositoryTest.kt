package co.za.mjscyber.data.repo

import co.za.mjscyber.data.api.ApiClient
import co.za.mjscyber.data.api.EnrolBody
import co.za.mjscyber.data.api.MjscyberApi
import co.za.mjscyber.data.dto.Course
import co.za.mjscyber.data.dto.Enrolment
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class CourseRepositoryTest {

    private lateinit var api: MjscyberApi
    private lateinit var client: ApiClient
    private lateinit var repo: CourseRepository

    private val sampleCourses = listOf(
        Course("c1", "PSIRA-E", "Grade E — Guarding basics", "E",
            "Entry-level curriculum", 5, 1500.0, true),
        Course("c2", "PSIRA-D", "Grade D — Access control", "D",
            "Intermediate", 7, 2200.0, true),
    )

    @Before
    fun setUp() {
        api    = mockk(relaxed = true)
        client = mockk { io.mockk.every { api } returns this@CourseRepositoryTest.api }
        repo   = CourseRepository(client)
    }

    @Test
    fun `courses returns success with parsed list`() = runTest {
        coEvery { api.courses() } returns sampleCourses
        val res = repo.courses()
        assertTrue(res.isSuccess)
        assertEquals(2, res.getOrDefault(emptyList()).size)
    }

    @Test
    fun `enrol posts the correct course id`() = runTest {
        val enrolment = Enrolment(
            id = "e1", student_id = "s1", course_id = "c1",
            status = "pending", payment_status = "pending",
            overall_mark = null, enrolled_at = "2026-06-15"
        )
        coEvery { api.enrol(any()) } returns enrolment

        val res = repo.enrol("c1")

        assertTrue(res.isSuccess)
        coVerify { api.enrol(EnrolBody("c1")) }
    }

    @Test
    fun `courses returns failure on api error`() = runTest {
        coEvery { api.courses() } throws RuntimeException("500")
        val res = repo.courses()
        assertTrue(res.isFailure)
    }
}
