package co.za.mjscyber.ui.theme

import androidx.compose.ui.graphics.Color

/** MJSCYBER brand palette — mirrors the web app (navy + red on dark surfaces). */
val MjBg           = Color(0xFF0A0B12)
val MjSurface      = Color(0xFF14161E)
val MjSurfaceHigh  = Color(0xFF1E2130)
val MjBorder       = Color(0xFF2C303E)
val MjPrimary      = Color(0xFF0B3D91)
val MjPrimaryDark  = Color(0xFF072B66)
val MjAccent       = Color(0xFFC0392B)
val MjAccentLight  = Color(0xFFE65546)
val MjText         = Color(0xFFF5F6FA)
val MjMuted        = Color(0xFFA5AAB9)
val MjSuccess      = Color(0xFF10B981)
val MjWarn         = Color(0xFFF59E0B)
val MjError        = Color(0xFFEF4444)
