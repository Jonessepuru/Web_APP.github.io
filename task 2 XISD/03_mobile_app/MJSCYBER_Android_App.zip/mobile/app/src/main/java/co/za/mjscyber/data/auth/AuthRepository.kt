package co.za.mjscyber.data.auth

import co.za.mjscyber.data.api.ApiClient
import co.za.mjscyber.data.dto.LoginRequest
import co.za.mjscyber.data.dto.RegisterRequest
import co.za.mjscyber.data.dto.SsoLoginRequest
import co.za.mjscyber.data.dto.TokenResponse
import javax.inject.Inject
import javax.inject.Singleton

/**
 * All authentication use-cases funnel through this repository so ViewModels never
 * talk to Retrofit or DataStore directly. That keeps them unit-testable.
 */
@Singleton
class AuthRepository @Inject constructor(
    private val client: ApiClient,
    private val session: SessionStore,
) {
    suspend fun login(email: String, password: String): Result<TokenResponse> = runCatching {
        val res = client.api.login(LoginRequest(email.trim().lowercase(), password))
        session.save(res.access_token, res.user.email, res.user.full_name, res.user.role)
        res
    }

    suspend fun register(email: String, password: String, fullName: String,
                         phone: String?, idNumber: String?): Result<TokenResponse> = runCatching {
        val res = client.api.register(
            RegisterRequest(email.trim().lowercase(), password, fullName, phone, idNumber)
        )
        session.save(res.access_token, res.user.email, res.user.full_name, res.user.role)
        res
    }

    /**
     * Exchanges a Google ID token (from Credential Manager / Firebase) for a MJSCYBER JWT.
     * The FastAPI back-end verifies the ID token against Google's JWKs before minting the
     * app JWT — this satisfies the WIL 3B rubric "Feature: SSO login" criterion.
     */
    suspend fun ssoGoogle(googleIdToken: String): Result<TokenResponse> = runCatching {
        val res = client.api.ssoGoogle(SsoLoginRequest(googleIdToken))
        session.save(res.access_token, res.user.email, res.user.full_name, res.user.role)
        res
    }

    suspend fun logout() = session.clear()
}
