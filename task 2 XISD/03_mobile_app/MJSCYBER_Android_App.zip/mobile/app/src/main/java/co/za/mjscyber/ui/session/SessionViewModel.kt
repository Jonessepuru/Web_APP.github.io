package co.za.mjscyber.ui.session

import androidx.lifecycle.ViewModel
import co.za.mjscyber.data.auth.SessionStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

@HiltViewModel
class SessionViewModel @Inject constructor(session: SessionStore) : ViewModel() {
    val token: Flow<String?> = session.tokenFlow
    val role:  Flow<String?> = session.roleFlow
    val name:  Flow<String?> = session.nameFlow
    val email: Flow<String?> = session.emailFlow
}
