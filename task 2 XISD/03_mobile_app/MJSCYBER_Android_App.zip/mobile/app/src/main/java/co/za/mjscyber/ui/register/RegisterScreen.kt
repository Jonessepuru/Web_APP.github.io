package co.za.mjscyber.ui.register

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
    onRegistered: () -> Unit,
    onGoToLogin: () -> Unit,
    vm: RegisterViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    LaunchedEffect(state.done) { if (state.done) onRegistered() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create account", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onGoToLogin) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { inner ->
        Column(
            Modifier
                .padding(inner)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(4.dp))
            Text("Enrol on the app to book PSIRA-grade courses, pay online and download digital certificates.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            OutlinedTextField(state.fullName, vm::onFullNameChange,
                label = { Text("Full name") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("reg-name"))
            OutlinedTextField(state.email, vm::onEmailChange,
                label = { Text("E-mail") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth().testTag("reg-email"))
            OutlinedTextField(state.phone, vm::onPhoneChange,
                label = { Text("Phone (optional)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth().testTag("reg-phone"))
            OutlinedTextField(state.idNumber, vm::onIdChange,
                label = { Text("SA ID (optional)") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("reg-id"))
            OutlinedTextField(state.password, vm::onPasswordChange,
                label = { Text("Password (8+ chars)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth().testTag("reg-password"))

            state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error,
                     style = MaterialTheme.typography.bodyMedium)
            }

            Button(
                onClick = vm::submit,
                enabled = !state.submitting,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("reg-submit"),
            ) {
                if (state.submitting) CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(22.dp)
                ) else Text("Create my account")
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}
