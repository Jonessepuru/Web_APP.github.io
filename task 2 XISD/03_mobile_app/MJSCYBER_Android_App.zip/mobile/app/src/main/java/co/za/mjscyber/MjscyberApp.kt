package co.za.mjscyber

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * MJSCYBER Application entry point.
 * Bootstraps Hilt dependency-injection so every ViewModel and Repository can be
 * resolved from a single object graph.
 */
@HiltAndroidApp
class MjscyberApp : Application()
