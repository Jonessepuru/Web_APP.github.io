package co.za.mjscyber.ui.certificates

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import co.za.mjscyber.data.dto.Certificate
import co.za.mjscyber.data.repo.CertificateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CertsUiState(
    val loading: Boolean = true,
    val items: List<Certificate> = emptyList(),
    val error: String? = null,
)

@HiltViewModel
class CertificatesViewModel @Inject constructor(
    private val repo: CertificateRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(CertsUiState())
    val state: StateFlow<CertsUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            val res = repo.mine()
            _state.value = if (res.isSuccess) {
                _state.value.copy(loading = false, items = res.getOrDefault(emptyList()))
            } else {
                _state.value.copy(loading = false, error = "Could not load certificates.")
            }
        }
    }
}
