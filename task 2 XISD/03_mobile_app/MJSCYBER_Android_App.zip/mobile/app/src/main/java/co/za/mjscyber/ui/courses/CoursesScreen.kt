package co.za.mjscyber.ui.courses

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import co.za.mjscyber.data.dto.Course
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoursesScreen(
    onBack: () -> Unit,
    vm: CoursesViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(state.toast) {
        state.toast?.let {
            scope.launch { snackbar.showSnackbar(it) }
            vm.clearToast()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Course catalogue", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { inner ->
        Column(Modifier.padding(inner)) {
            when {
                state.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                state.error != null -> Text(state.error!!, Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.error)
                else -> LazyColumn(
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.items, key = { it.id }) { c ->
                        CourseCard(c, isEnrolling = state.enrolling == c.id, onEnrol = { vm.enrol(c) })
                    }
                }
            }
        }
    }
}

@Composable
private fun CourseCard(c: Course, isEnrolling: Boolean, onEnrol: () -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = {}, label = { Text(c.code) })
                Spacer(Modifier.width(8.dp))
                c.grade?.let { AssistChip(onClick = {}, label = { Text("Grade $it") }) }
                Spacer(Modifier.weight(1f))
                Text("R${c.price_zar.toInt()}", style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.height(10.dp))
            Text(c.title, style = MaterialTheme.typography.titleLarge)
            Text(c.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3)
            Spacer(Modifier.height(6.dp))
            Text("Duration: ${c.duration_days} days",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onEnrol,
                enabled = !isEnrolling,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                if (isEnrolling) CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp)
                ) else Text("Enrol")
            }
        }
    }
}
