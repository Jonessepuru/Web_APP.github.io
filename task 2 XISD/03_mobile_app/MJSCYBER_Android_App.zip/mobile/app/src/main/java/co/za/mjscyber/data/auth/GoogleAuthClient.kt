package co.za.mjscyber.data.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import co.za.mjscyber.BuildConfig
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Thin wrapper around the AndroidX Credential Manager + Google Identity library.
 * Returns a Google-signed ID token that the FastAPI back-end can verify.
 *
 * WIL 3B rubric: "Users must be able to register and log in" + "SSO login" — this file
 * handles the SSO half; server-side verification lives in FastAPI at /api/auth/sso/google.
 */
@Singleton
class GoogleAuthClient @Inject constructor(
    @ApplicationContext private val ctx: Context,
) {
    private val credentialManager: CredentialManager = CredentialManager.create(ctx)

    suspend fun requestIdToken(activityContext: Context): Result<String> = runCatching {
        require(BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()) {
            "GOOGLE_WEB_CLIENT_ID missing from local.properties — add it to enable SSO."
        }
        val googleOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .setAutoSelectEnabled(true)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleOption)
            .build()

        val response = credentialManager.getCredential(activityContext, request)
        val cred = response.credential
        check(cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            "Unexpected credential type ${cred::class.simpleName}"
        }
        GoogleIdTokenCredential.createFrom(cred.data).idToken
    }
}
