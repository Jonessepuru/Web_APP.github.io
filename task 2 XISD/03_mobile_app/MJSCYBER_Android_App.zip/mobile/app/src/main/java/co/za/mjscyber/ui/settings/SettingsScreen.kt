package co.za.mjscyber.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import co.za.mjscyber.ui.theme.MjAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onLoggedOut: () -> Unit,
    vm: SettingsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    val loggedOut by vm.loggedOut.collectAsState()
    LaunchedEffect(loggedOut) { if (loggedOut) onLoggedOut() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { inner ->
        Column(Modifier.padding(inner).padding(20.dp),
               verticalArrangement = Arrangement.spacedBy(14.dp)) {

            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Person, null, tint = MjAccent,
                        modifier = Modifier.size(40.dp))
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(state.fullName.ifBlank { "MJSCYBER user" },
                            style = MaterialTheme.typography.titleLarge)
                        Text(state.email, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium)
                        AssistChip(onClick = {}, label = { Text(state.role) })
                    }
                }
            }

            SettingRow(
                icon = Icons.Filled.DarkMode,
                title = "Dark theme",
                subtitle = "Match my system's dark appearance",
                trailing = { Switch(checked = state.darkTheme, onCheckedChange = vm::setDark) }
            )
            SettingRow(
                icon = Icons.Filled.Notifications,
                title = "Push notifications",
                subtitle = "Course updates and shift alerts",
                trailing = { Switch(checked = state.notifications, onCheckedChange = vm::setNotifications) }
            )

            Spacer(Modifier.weight(1f))

            OutlinedButton(
                onClick = vm::logout,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Filled.Logout, null); Spacer(Modifier.width(8.dp))
                Text("Log out")
            }

            Text("MJSCYBER Mobile v1.0.0 · Jones Sepuru & Khumela Sendelani",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit,
) {
    ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MjAccent)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            trailing()
        }
    }
}
