package co.za.mjscyber.data.dto

import kotlinx.serialization.Serializable

/** All API DTOs mirror the FastAPI response shapes exactly. */

@Serializable
data class LoginRequest(val email: String, val password: String)

@Serializable
data class RegisterRequest(
    val email: String,
    val password: String,
    val name: String,
    val phone: String? = null,
    val id_number: String? = null,
)

@Serializable
data class TokenResponse(val access_token: String, val user: User)

@Serializable
data class User(
    val id: String,
    val email: String,
    val role: String,
    val full_name: String,
    val phone: String? = null,
    val id_number: String? = null,
)

@Serializable
data class Course(
    val id: String,
    val code: String,
    val title: String,
    val grade: String? = null,
    val description: String,
    val duration_days: Int,
    val price_zar: Double,
    val is_active: Boolean = true,
)

@Serializable
data class Enrolment(
    val id: String,
    val student_id: String,
    val course_id: String,
    val status: String,                // pending | approved | completed | failed
    val payment_status: String,        // pending | paid
    val overall_mark: Double? = null,
    val enrolled_at: String,
)

@Serializable
data class Certificate(
    val id: String,
    val serial: String,
    val student_id: String,
    val student_name: String,
    val course_id: String,
    val course_title: String,
    val course_code: String,
    val overall_mark: Double? = null,
    val issued_at: String,
    val valid: Boolean = true,
)

@Serializable
data class SsoLoginRequest(val id_token: String)
