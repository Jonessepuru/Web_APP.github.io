package co.za.mjscyber.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import co.za.mjscyber.data.auth.SessionStore
import co.za.mjscyber.data.dto.Enrolment
import co.za.mjscyber.data.repo.CourseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val loading: Boolean = true,
    val greeting: String = "",
    val enrolments: List<Enrolment> = emptyList(),
    val error: String? = null,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val courses: CourseRepository,
    session: SessionStore,
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            session.nameFlow.collect { name ->
                _state.value = _state.value.copy(greeting = "Hello, ${name?.substringBefore(' ') ?: "Guardian"}")
            }
        }
        refresh()
    }

    fun refresh() {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            val res = courses.myEnrolments()
            _state.value = if (res.isSuccess) {
                _state.value.copy(loading = false, enrolments = res.getOrDefault(emptyList()))
            } else {
                _state.value.copy(loading = false, error = "Could not load your enrolments.")
            }
        }
    }
}
