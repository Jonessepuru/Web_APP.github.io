package co.za.mjscyber.data.api

import co.za.mjscyber.data.dto.Certificate
import co.za.mjscyber.data.dto.Course
import co.za.mjscyber.data.dto.Enrolment
import co.za.mjscyber.data.dto.LoginRequest
import co.za.mjscyber.data.dto.RegisterRequest
import co.za.mjscyber.data.dto.SsoLoginRequest
import co.za.mjscyber.data.dto.TokenResponse
import co.za.mjscyber.data.dto.User
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * Retrofit contract for the MJSCYBER FastAPI back-end.
 * All endpoints are prefixed with /api on the server side.
 */
interface MjscyberApi {

    // ---------- Auth ----------
    @POST("api/auth/mobile/login")
    suspend fun login(@Body body: LoginRequest): TokenResponse

    @POST("api/auth/mobile/register")
    suspend fun register(@Body body: RegisterRequest): TokenResponse

    /** Server-side Google-token verification (Firebase ID-token → backend session). */
    @POST("api/auth/sso/google")
    suspend fun ssoGoogle(@Body body: SsoLoginRequest): TokenResponse

    @GET("api/auth/me")
    suspend fun me(): User

    // ---------- Courses ----------
    @GET("api/courses")
    suspend fun courses(): List<Course>

    // ---------- Enrolments ----------
    @POST("api/enrolments")
    suspend fun enrol(@Body body: EnrolBody): Enrolment

    @GET("api/enrolments/mine")
    suspend fun myEnrolments(): List<Enrolment>

    // ---------- Certificates ----------
    @GET("api/certificates/mine")
    suspend fun myCertificates(): List<Certificate>

    @GET("api/verify/{serial}")
    suspend fun verify(@Path("serial") serial: String): Certificate
}

@kotlinx.serialization.Serializable
data class EnrolBody(val course_id: String)
