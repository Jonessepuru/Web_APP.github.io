package co.za.mjscyber.ui.register

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import co.za.mjscyber.data.auth.AuthRepository
import co.za.mjscyber.ui.login.userMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RegisterUiState(
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val idNumber: String = "",
    val password: String = "",
    val submitting: Boolean = false,
    val error: String? = null,
    val done: Boolean = false,
)

@HiltViewModel
class RegisterViewModel @Inject constructor(private val auth: AuthRepository) : ViewModel() {

    private val _state = MutableStateFlow(RegisterUiState())
    val state: StateFlow<RegisterUiState> = _state.asStateFlow()

    fun onFullNameChange(v: String) { _state.value = _state.value.copy(fullName = v) }
    fun onEmailChange(v: String)    { _state.value = _state.value.copy(email = v) }
    fun onPhoneChange(v: String)    { _state.value = _state.value.copy(phone = v) }
    fun onIdChange(v: String)       { _state.value = _state.value.copy(idNumber = v) }
    fun onPasswordChange(v: String) { _state.value = _state.value.copy(password = v) }

    fun submit() {
        val s = _state.value
        val errors = buildList {
            if (s.fullName.isBlank())        add("full name")
            if (s.email.isBlank())           add("e-mail")
            if (s.password.length < 8)       add("password (min 8 chars)")
        }
        if (errors.isNotEmpty()) {
            _state.value = s.copy(error = "Missing/invalid: ${errors.joinToString(", ")}")
            return
        }
        _state.value = s.copy(submitting = true, error = null)
        viewModelScope.launch {
            val res = auth.register(
                email = s.email, password = s.password, fullName = s.fullName,
                phone = s.phone.ifBlank { null }, idNumber = s.idNumber.ifBlank { null }
            )
            _state.value = if (res.isSuccess) {
                _state.value.copy(submitting = false, done = true)
            } else {
                _state.value.copy(submitting = false, error = res.exceptionOrNull()?.userMessage() ?: "Sign up failed.")
            }
        }
    }
}
