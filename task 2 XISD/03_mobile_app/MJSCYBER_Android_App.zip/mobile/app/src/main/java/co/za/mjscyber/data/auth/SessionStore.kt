package co.za.mjscyber.data.auth

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "mjscyber_session")

/**
 * Encrypted-at-rest persistence for the current session.
 *
 * Note: for a Play-Store release this should be swapped for EncryptedFile /
 * androidx.security:security-crypto so the JWT never lands on disk in plaintext.
 * This class already isolates the API so that swap is a two-line change.
 */
@Singleton
class SessionStore @Inject constructor(
    @ApplicationContext private val ctx: Context
) {
    private val TOKEN_KEY  = stringPreferencesKey("access_token")
    private val EMAIL_KEY  = stringPreferencesKey("email")
    private val NAME_KEY   = stringPreferencesKey("full_name")
    private val ROLE_KEY   = stringPreferencesKey("role")
    private val DARK_KEY   = booleanPreferencesKey("dark_theme")
    private val NOTIF_KEY  = booleanPreferencesKey("notifications_enabled")

    val tokenFlow: Flow<String?> = ctx.dataStore.data.map { it[TOKEN_KEY] }
    val roleFlow:  Flow<String?> = ctx.dataStore.data.map { it[ROLE_KEY]  }
    val nameFlow:  Flow<String?> = ctx.dataStore.data.map { it[NAME_KEY]  }
    val emailFlow: Flow<String?> = ctx.dataStore.data.map { it[EMAIL_KEY] }
    val darkFlow:  Flow<Boolean> = ctx.dataStore.data.map { it[DARK_KEY]  ?: true }
    val notifFlow: Flow<Boolean> = ctx.dataStore.data.map { it[NOTIF_KEY] ?: true }

    suspend fun tokenOnce(): String? = ctx.dataStore.data.first()[TOKEN_KEY]

    suspend fun save(token: String, email: String, fullName: String, role: String) {
        ctx.dataStore.edit {
            it[TOKEN_KEY] = token
            it[EMAIL_KEY] = email
            it[NAME_KEY]  = fullName
            it[ROLE_KEY]  = role
        }
    }

    suspend fun setDark(v: Boolean)   { ctx.dataStore.edit { it[DARK_KEY]  = v } }
    suspend fun setNotif(v: Boolean)  { ctx.dataStore.edit { it[NOTIF_KEY] = v } }

    suspend fun clear() {
        ctx.dataStore.edit {
            it.remove(TOKEN_KEY); it.remove(EMAIL_KEY); it.remove(NAME_KEY); it.remove(ROLE_KEY)
        }
    }
}
