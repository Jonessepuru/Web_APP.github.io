package co.za.mjscyber.ui.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import co.za.mjscyber.ui.certificates.CertificatesScreen
import co.za.mjscyber.ui.courses.CoursesScreen
import co.za.mjscyber.ui.home.HomeScreen
import co.za.mjscyber.ui.login.LoginScreen
import co.za.mjscyber.ui.register.RegisterScreen
import co.za.mjscyber.ui.session.SessionViewModel
import co.za.mjscyber.ui.settings.SettingsScreen

object Routes {
    const val Login         = "login"
    const val Register      = "register"
    const val Home          = "home"
    const val Courses       = "courses"
    const val Certificates  = "certificates"
    const val Settings      = "settings"
}

@Composable
fun MjscyberNavHost(
    navController: NavHostController = rememberNavController(),
    sessionVm: SessionViewModel = hiltViewModel(),
) {
    val token by sessionVm.token.collectAsState(initial = null)
    val start = if (token.isNullOrBlank()) Routes.Login else Routes.Home

    NavHost(navController = navController, startDestination = start) {
        composable(Routes.Login) {
            LoginScreen(
                onLoggedIn      = { navController.navigate(Routes.Home) { popUpTo(Routes.Login) { inclusive = true } } },
                onGoToRegister  = { navController.navigate(Routes.Register) },
            )
        }
        composable(Routes.Register) {
            RegisterScreen(
                onRegistered    = { navController.navigate(Routes.Home) { popUpTo(Routes.Login) { inclusive = true } } },
                onGoToLogin     = { navController.popBackStack() },
            )
        }
        composable(Routes.Home)          { HomeScreen(navController) }
        composable(Routes.Courses)       { CoursesScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.Certificates)  { CertificatesScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.Settings) {
            SettingsScreen(
                onBack     = { navController.popBackStack() },
                onLoggedOut = { navController.navigate(Routes.Login) { popUpTo(0) } },
            )
        }
    }
}
