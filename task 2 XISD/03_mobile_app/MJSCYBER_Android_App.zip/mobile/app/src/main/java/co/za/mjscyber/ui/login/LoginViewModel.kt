package co.za.mjscyber.ui.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import co.za.mjscyber.data.auth.AuthRepository
import co.za.mjscyber.data.auth.GoogleAuthClient
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val submitting: Boolean = false,
    val error: String? = null,
    val loggedIn: Boolean = false,
)

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val auth: AuthRepository,
    private val google: GoogleAuthClient,
) : ViewModel() {

    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    fun onEmailChange(v: String)    { _state.value = _state.value.copy(email = v) }
    fun onPasswordChange(v: String) { _state.value = _state.value.copy(password = v) }

    fun submit() {
        val s = _state.value
        if (s.email.isBlank() || s.password.isBlank()) {
            _state.value = s.copy(error = "Please enter your e-mail and password.")
            return
        }
        _state.value = s.copy(submitting = true, error = null)
        viewModelScope.launch {
            val res = auth.login(s.email, s.password)
            _state.value = if (res.isSuccess) {
                _state.value.copy(submitting = false, loggedIn = true)
            } else {
                Log.e("Login", "Login failed", res.exceptionOrNull())
                _state.value.copy(
                    submitting = false,
                    error = res.exceptionOrNull()?.userMessage() ?: "Login failed. Please try again."
                )
            }
        }
    }

    fun signInWithGoogle(ctx: Context) {
        _state.value = _state.value.copy(submitting = true, error = null)
        viewModelScope.launch {
            val tokenRes = google.requestIdToken(ctx)
            val idToken = tokenRes.getOrNull()
            if (idToken.isNullOrBlank()) {
                _state.value = _state.value.copy(
                    submitting = false,
                    error = tokenRes.exceptionOrNull()?.userMessage() ?: "Google sign-in was cancelled."
                )
                return@launch
            }
            val ssoRes = auth.ssoGoogle(idToken)
            _state.value = if (ssoRes.isSuccess) {
                _state.value.copy(submitting = false, loggedIn = true)
            } else {
                Log.e("Login", "SSO failed", ssoRes.exceptionOrNull())
                _state.value.copy(
                    submitting = false,
                    error = ssoRes.exceptionOrNull()?.userMessage() ?: "Could not verify Google account."
                )
            }
        }
    }
}

/** Human-readable form of common network exceptions. */
internal fun Throwable.userMessage(): String = when (this) {
    is java.net.UnknownHostException, is java.net.ConnectException ->
        "No internet connection. Please check your network and try again."
    is retrofit2.HttpException -> when (code()) {
        401, 403 -> "Invalid credentials."
        429      -> "Too many attempts — please wait a few minutes."
        else     -> "Server error (${code()})."
    }
    else -> message?.take(120) ?: "Unexpected error."
}
