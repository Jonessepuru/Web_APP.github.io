package co.za.mjscyber.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Marker Hilt module — most bindings in this app use @Inject constructors, so this file
 * currently has no provides methods but is kept for future manual bindings (e.g. mock
 * repositories in a demo flavour).
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule
