package co.za.mjscyber.ui.courses

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import co.za.mjscyber.data.dto.Course
import co.za.mjscyber.data.repo.CourseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CoursesUiState(
    val loading: Boolean = true,
    val items: List<Course> = emptyList(),
    val enrolling: String? = null,
    val toast: String? = null,
    val error: String? = null,
)

@HiltViewModel
class CoursesViewModel @Inject constructor(
    private val repo: CourseRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(CoursesUiState())
    val state: StateFlow<CoursesUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            val res = repo.courses()
            _state.value = if (res.isSuccess) {
                _state.value.copy(loading = false, items = res.getOrDefault(emptyList()))
            } else {
                _state.value.copy(loading = false, error = "Could not load courses.")
            }
        }
    }

    fun enrol(course: Course) {
        _state.value = _state.value.copy(enrolling = course.id, toast = null)
        viewModelScope.launch {
            val res = repo.enrol(course.id)
            _state.value = _state.value.copy(
                enrolling = null,
                toast = if (res.isSuccess) "Enrolled on ${course.code} — please complete payment on the web app."
                        else "Could not enrol. Try again shortly."
            )
        }
    }

    fun clearToast() { _state.value = _state.value.copy(toast = null) }
}
