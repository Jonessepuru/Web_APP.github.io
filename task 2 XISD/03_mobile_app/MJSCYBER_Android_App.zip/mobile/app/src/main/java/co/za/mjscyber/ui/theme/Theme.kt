package co.za.mjscyber.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary       = MjAccent,
    onPrimary     = MjText,
    secondary     = MjPrimary,
    onSecondary   = MjText,
    background    = MjBg,
    onBackground  = MjText,
    surface       = MjSurface,
    onSurface     = MjText,
    surfaceVariant = MjSurfaceHigh,
    onSurfaceVariant = MjMuted,
    error         = MjError,
    outline       = MjBorder,
)

private val LightColors = lightColorScheme(
    primary       = MjPrimary,
    onPrimary     = MjText,
    secondary     = MjAccent,
    onSecondary   = MjText,
    background    = MjText,
    onBackground  = MjBg,
    surface       = MjText,
    onSurface     = MjBg,
    error         = MjError,
    outline       = MjBorder,
)

@Composable
fun MjscyberTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography  = MjscyberTypography,
        content     = content
    )
}
