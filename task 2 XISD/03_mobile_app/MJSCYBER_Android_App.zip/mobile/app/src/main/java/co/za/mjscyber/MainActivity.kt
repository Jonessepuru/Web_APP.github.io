package co.za.mjscyber

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import co.za.mjscyber.ui.nav.MjscyberNavHost
import co.za.mjscyber.ui.theme.MjscyberTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-Activity architecture — hosts the Compose navigation graph.
 * Uses AndroidEntryPoint so Hilt can inject dependencies into any child ViewModel.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MjscyberTheme {
                MjscyberNavHost()
            }
        }
    }
}
