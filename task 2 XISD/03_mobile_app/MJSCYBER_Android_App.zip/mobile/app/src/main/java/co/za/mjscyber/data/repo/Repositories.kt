package co.za.mjscyber.data.repo

import co.za.mjscyber.data.api.ApiClient
import co.za.mjscyber.data.api.EnrolBody
import co.za.mjscyber.data.dto.Certificate
import co.za.mjscyber.data.dto.Course
import co.za.mjscyber.data.dto.Enrolment
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CourseRepository @Inject constructor(private val client: ApiClient) {
    suspend fun courses(): Result<List<Course>> = runCatching { client.api.courses() }
    suspend fun enrol(courseId: String): Result<Enrolment> = runCatching {
        client.api.enrol(EnrolBody(courseId))
    }
    suspend fun myEnrolments(): Result<List<Enrolment>> = runCatching { client.api.myEnrolments() }
}

@Singleton
class CertificateRepository @Inject constructor(private val client: ApiClient) {
    suspend fun mine(): Result<List<Certificate>> = runCatching { client.api.myCertificates() }
    suspend fun verify(serial: String): Result<Certificate> = runCatching { client.api.verify(serial) }
}
