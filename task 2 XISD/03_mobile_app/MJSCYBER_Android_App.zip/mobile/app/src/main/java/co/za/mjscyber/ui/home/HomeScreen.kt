package co.za.mjscyber.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Award
import androidx.compose.material.icons.filled.BookOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import co.za.mjscyber.data.dto.Enrolment
import co.za.mjscyber.ui.nav.Routes
import co.za.mjscyber.ui.theme.MjAccent
import co.za.mjscyber.ui.theme.MjSuccess
import co.za.mjscyber.ui.theme.MjWarn

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    nav: NavHostController,
    vm: HomeViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MJSCYBER", fontWeight = FontWeight.Black) },
                actions = {
                    IconButton(onClick = vm::refresh) {
                        Icon(Icons.Filled.Refresh, "Refresh")
                    }
                    IconButton(onClick = { nav.navigate(Routes.Settings) }) {
                        Icon(Icons.Filled.Settings, "Settings")
                    }
                }
            )
        }
    ) { inner ->
        Column(Modifier.padding(inner).padding(horizontal = 20.dp)) {
            Text(state.greeting, style = MaterialTheme.typography.headlineLarge)
            Text("Your training at a glance",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(Modifier.height(20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeTile("Courses", Icons.Filled.BookOpen, Modifier.weight(1f)) {
                    nav.navigate(Routes.Courses)
                }
                HomeTile("Certificates", Icons.Filled.Award, Modifier.weight(1f)) {
                    nav.navigate(Routes.Certificates)
                }
            }

            Spacer(Modifier.height(28.dp))
            Text("My enrolments", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))

            when {
                state.loading -> Box(Modifier.fillMaxWidth().padding(30.dp),
                    contentAlignment = Alignment.Center) { CircularProgressIndicator() }

                state.error != null -> Text(state.error!!, color = MaterialTheme.colorScheme.error)

                state.enrolments.isEmpty() -> Text(
                    "You haven't enrolled on any courses yet — browse the catalogue to get started.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.enrolments, key = { it.id }) { EnrolmentRow(it) }
                    item { Spacer(Modifier.height(12.dp)) }
                }
            }
        }
    }
}

@Composable
private fun HomeTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                    modifier: Modifier, onClick: () -> Unit) {
    ElevatedCard(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.height(120.dp).fillMaxWidth(),
    ) {
        Column(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Icon(icon, contentDescription = null, tint = MjAccent)
            Text(label, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun EnrolmentRow(e: Enrolment) {
    ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(e.course_id, style = MaterialTheme.typography.titleMedium)
                Text("Enrolled: ${e.enrolled_at.take(10)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                e.overall_mark?.let {
                    Text("Mark: $it%", style = MaterialTheme.typography.bodyMedium)
                }
            }
            val statusColor = when (e.status) {
                "completed" -> MjSuccess
                "failed"    -> MaterialTheme.colorScheme.error
                else        -> MjWarn
            }
            AssistChip(onClick = {}, label = { Text(e.status) },
                colors = AssistChipDefaults.assistChipColors(labelColor = statusColor))
        }
    }
}
