package co.za.mjscyber.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import co.za.mjscyber.data.auth.AuthRepository
import co.za.mjscyber.data.auth.SessionStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val email: String = "",
    val fullName: String = "",
    val role: String = "",
    val darkTheme: Boolean = true,
    val notifications: Boolean = true,
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val session: SessionStore,
    private val auth: AuthRepository,
) : ViewModel() {

    private val _loggedOut = MutableStateFlow(false)
    val loggedOut: StateFlow<Boolean> = _loggedOut

    val state: StateFlow<SettingsUiState> = kotlinx.coroutines.flow.combine(
        session.emailFlow, session.nameFlow, session.roleFlow,
        session.darkFlow,  session.notifFlow,
    ) { arr ->
        SettingsUiState(
            email = arr[0] as String? ?: "",
            fullName = arr[1] as String? ?: "",
            role = arr[2] as String? ?: "student",
            darkTheme = arr[3] as Boolean,
            notifications = arr[4] as Boolean,
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, SettingsUiState())

    fun setDark(v: Boolean)      = viewModelScope.launch { session.setDark(v) }
    fun setNotifications(v: Boolean) = viewModelScope.launch { session.setNotif(v) }

    fun logout() = viewModelScope.launch {
        auth.logout()
        _loggedOut.value = true
    }
}
